@if($type == 'label' && $module == 'productTag')
	<label style="background-color:{{ $row->color }};padding:12px"></label>
@endif