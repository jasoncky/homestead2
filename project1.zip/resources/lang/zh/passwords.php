<?php

return [
    'password' => '密碼必須至少包含六個字符並與確保確認密碼相符。',
    'reset'    => '密碼重設成功',
    'sent'     => '我們已發送電子郵件去你的電子郵箱',
    'token'    => '重設密碼令牌無效',
    'user'     => '我們無法找到用戶',
    'updated'  => 'Your password has been changed!',
];
