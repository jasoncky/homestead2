<?php

return [
    'site_title' => 'myapps',
];
