<?php

return [
    'previous' => '&laquo; 前',
    'next'     => '下一个 &raquo;',
];
