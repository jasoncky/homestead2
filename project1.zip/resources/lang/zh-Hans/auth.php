<?php

return [
    'failed'   => '这些凭据与我们的记录不匹配。',
    'throttle' => '登录尝试过多。请在 :seconds后重试。',
];
